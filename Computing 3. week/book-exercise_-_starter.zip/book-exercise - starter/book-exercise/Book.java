/**
 * A class that maintains information on a book.
 * This might form part of a larger application such
 * as a library system, for instance.
 *
 * @author ()
 * @version (1)
 */
class Book
{
    private String author;
    private String title;

    /**
     * constructor 1
     */
    public Book(String bookAuthor, String bookTitle)
    {

    }

    /**
     * constructor 2
     */
    public Book()
    {

    }

    public void setRefNumber(String _refNumber)
    {
        ;
    }

    public void printRef()
    {

    }
    //mutator method
    public void borrow()
    {

    }       
    
}
