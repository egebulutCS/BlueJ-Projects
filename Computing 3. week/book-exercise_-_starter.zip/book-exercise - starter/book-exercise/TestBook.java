
/**
 * Write a description of class TestBook here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestBook
{
   private Book bk;
   
    public TestBook()
    {
        bk = new Book("Ege","My visit to Milan",125);
        
    }

   
}
